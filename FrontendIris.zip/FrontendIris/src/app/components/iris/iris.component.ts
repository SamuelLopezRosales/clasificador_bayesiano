import { Component, Input, OnInit } from '@angular/core';
import { Iris } from 'src/app/interfaces/intefaces';

@Component({
  selector: 'app-iris',
  templateUrl: './iris.component.html',
  styleUrls: ['./iris.component.scss'],
})
export class IrisComponent implements OnInit {
  @Input() iris: Iris[] = [];
  constructor() { }

  ngOnInit() {}

}
