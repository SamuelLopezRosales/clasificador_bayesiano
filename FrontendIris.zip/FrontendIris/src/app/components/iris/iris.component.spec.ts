import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { IrisComponent } from './iris.component';

describe('IrisComponent', () => {
  let component: IrisComponent;
  let fixture: ComponentFixture<IrisComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IrisComponent ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(IrisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
