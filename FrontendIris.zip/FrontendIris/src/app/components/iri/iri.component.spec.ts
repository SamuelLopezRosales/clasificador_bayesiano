import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { IriComponent } from './iri.component';

describe('IriComponent', () => {
  let component: IriComponent;
  let fixture: ComponentFixture<IriComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IriComponent ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(IriComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
