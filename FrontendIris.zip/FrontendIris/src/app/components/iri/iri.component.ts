import { Component, Input, OnInit } from '@angular/core';
import { Iris } from '../../interfaces/intefaces';

@Component({
  selector: 'app-iri',
  templateUrl: './iri.component.html',
  styleUrls: ['./iri.component.scss'],
})
export class IriComponent implements OnInit {
  @Input() iri: Iris = {};
  constructor() { }

  ngOnInit() {}

}
