import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IrisComponent } from './iris/iris.component';
import { IriComponent } from './iri/iri.component';
import { IonicModule } from '@ionic/angular';



@NgModule({
  declarations: [
    IrisComponent,
    IriComponent
  ],
  exports: [
    IrisComponent,
    IriComponent
  ],
  imports: [
    CommonModule,
    IonicModule
  ]
})
export class ComponentsModule { }
