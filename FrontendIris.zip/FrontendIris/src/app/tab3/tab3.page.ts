import { Component, OnInit } from '@angular/core';
import { Iris } from '../interfaces/intefaces';
import { IrisService } from '../services/iris.service';
import { NgForm } from "@angular/forms";
import { ToastController } from '@ionic/angular'

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page implements OnInit {
  irisE: Iris[] = [];

  Datos = {
    sepal_length: null,
    sepal_with: null,
    petal_length: null,
    petal_width: null,
    clase: null
  }

  

  constructor(private irisService: IrisService, public toastController: ToastController) {}

  ngOnInit(){
    this.irisService.getIris()
    .subscribe( resp => {
      // guardo los datos iris en el arreglo 
      this.irisE.push( ...resp.iris );
    });

  }

  async presentToast(mensaje) {
    const toast = await this.toastController.create({
      message: mensaje,
      duration: 5000
    });
    toast.present();
  }



  
  crearRegistro(fRegistro: NgForm) {
    // valido el formulario //
    if (fRegistro.invalid) {
      return;
    }

    console.log(this.Datos.sepal_length);
    console.log(this.Datos.sepal_with);
    console.log(this.Datos.petal_length);
    console.log(this.Datos.petal_width);
    
    let conSLsetosa=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].sepal_length === this.Datos.sepal_length && this.irisE[i].class === "Iris-setosa"){
            conSLsetosa = conSLsetosa + 1;
      }
    }

    let conSWsetosa=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].sepal_width === this.Datos.sepal_with && this.irisE[i].class === "Iris-setosa"){
            conSWsetosa = conSWsetosa + 1;
      }
    }

    let conPLsetosa=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].petal_length === this.Datos.petal_length && this.irisE[i].class === "Iris-setosa"){
            conPLsetosa = conPLsetosa + 1;
      }
    }

    let conPWsetosa=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].petal_width === this.Datos.petal_width && this.irisE[i].class === "Iris-setosa"){
            conPWsetosa = conPWsetosa + 1;
      }
    }

    /*=========== CONTADORES DE VERSICOLOR ============*/
    let conSLversicolor=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].sepal_length === this.Datos.sepal_length && this.irisE[i].class === "Iris-versicolor"){
            conSLversicolor = conSLversicolor + 1;
      }
    }

    let conSWversicolor=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].sepal_width === this.Datos.sepal_with && this.irisE[i].class === "Iris-versicolor"){
            conSWversicolor = conSWversicolor + 1;
      }
    }

    let conPLversicolor=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].petal_length === this.Datos.petal_length && this.irisE[i].class === "Iris-versicolor"){
            conPLversicolor = conPLversicolor + 1;
      }
    }

    let conPWversicolor=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].petal_width === this.Datos.petal_width && this.irisE[i].class === "Iris-versicolor"){
            conPWversicolor = conPWversicolor + 1;
      }
    }


    /*=========== CONTADORES DE VIRGINICA ============*/
    let conSLvirginica=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].sepal_length === this.Datos.sepal_length && this.irisE[i].class === "Iris-virginica"){
            conSLvirginica = conSLvirginica + 1;
      }
    }

    let conSWvirginica=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].sepal_width === this.Datos.sepal_with && this.irisE[i].class === "Iris-virginica"){
            conSWvirginica = conSWvirginica + 1;
      }
    }

    let conPLvirginica=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].petal_length === this.Datos.petal_length && this.irisE[i].class === "Iris-virginica"){
            conPLvirginica = conPLvirginica + 1;
      }
    }

    let conPWvirginica=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].petal_width === this.Datos.petal_width && this.irisE[i].class === "Iris-virginica"){
            conPWvirginica = conPWvirginica + 1;
      }
    }


    
    /*=========== CONTADORES DE GENERAL ============*/
    let conSLgeneral=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].sepal_length === this.Datos.sepal_length){
            conSLgeneral = conSLgeneral + 1;
      }
    }

    let conSWgeneral=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].sepal_width === this.Datos.sepal_with){
            conSWgeneral = conSWgeneral + 1;
      }
    }

    let conPLgeneral=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].petal_length === this.Datos.petal_length){
            conPLgeneral = conPLgeneral + 1;
      }
    }

    let conPWgeneral=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].petal_width === this.Datos.petal_width){
            conPWgeneral = conPWgeneral + 1;
      }
    }

    // realizo los calculos //
    let probSetosa = (conSLsetosa/33) * (conSWsetosa/33) * (conPLsetosa/33) * (conPWsetosa/33) * (33/99);
    let probVersicolor = (conSLversicolor/33) * (conSWversicolor/33) * (conPLversicolor/33) * (conPWversicolor/33) * (33/99);
    let probVirginica = (conSLvirginica/33) * (conSWvirginica/33) * (conPLvirginica/33) * (conPWvirginica/33) * (33/99);
    let probGeneral = (conSLgeneral/99) * (conSWgeneral/99) * (conPLgeneral/99) * (conPWgeneral/99);
    
    // calculos para cuando los 3 sean ceros 
    let aciertosSetosa = conSLsetosa + conSWsetosa + conPLsetosa + conPWsetosa;
    let aciertosVersicolor = conSLversicolor + conSWversicolor + conPLversicolor + conPWversicolor;
    let aciertosVirginica = conSLvirginica + conSWvirginica + conPLvirginica + conPWvirginica;
    let finalSetosa = 0;
    if(probSetosa !== 0){
        finalSetosa = probSetosa / probGeneral;
    }else{
        finalSetosa = 0;
    }

    let finalVersicolor = 0;
    if(probVersicolor !== 0){
        finalVersicolor = probVersicolor / probGeneral;
    }else{
        finalVersicolor = 0;
    }

    let finalVirginica = 0;
    if(probVirginica !== 0){
        finalVirginica = probVirginica / probGeneral;
    }else{
        finalVirginica = 0;
    }
    

    if(finalSetosa > finalVersicolor && finalSetosa > finalVirginica){
      this.Datos.clase = "Iris-setosa";
    }else if(finalVersicolor > finalSetosa && finalVersicolor > finalVirginica){
      this.Datos.clase = "Iris-versicolor";
    }else if(finalVirginica > finalSetosa && finalVirginica > finalVersicolor){
      this.Datos.clase = "Iris-virginica";
    }else if(finalSetosa === finalVersicolor && finalSetosa === finalVirginica){
      if(aciertosSetosa > aciertosVersicolor && aciertosSetosa > aciertosVirginica){
        this.Datos.clase = "Iris-setosa";
      }else if(aciertosVersicolor > aciertosSetosa && aciertosVersicolor > aciertosVirginica){
        this.Datos.clase = "Iris-versicolor";
      }else if(aciertosVirginica > aciertosSetosa && aciertosVirginica > aciertosVersicolor){
        this.Datos.clase = "Iris-virginica";
      }else{
        this.Datos.clase = "Iris-setosa";
      }
     

      // mostrar un TOAST CON EL RESULTADO //
      
    }
    this.presentToast("Su clasificación es " + this.Datos.clase);


    
  }
}
