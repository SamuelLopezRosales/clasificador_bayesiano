import { Component, OnInit } from '@angular/core';
import { Iris } from '../interfaces/intefaces';
import { IrisService } from '../services/iris.service';
import { LoadingController } from '@ionic/angular'; 


@Component({
  selector: 'app-tab4',
  templateUrl: 'tab4.page.html',
  styleUrls: ['tab4.page.scss']
})
export class Tab4Page implements OnInit {
  iris: Iris[] = [];
  irisE: Iris[] = [];
  loading = this.loadingCtrl.create({message: 'Espere...'});

  constructor(private irisService: IrisService, private loadingCtrl: LoadingController) {}

  ngOnInit(){
    
    this.getDatos();
    this.getDatosEn();
  }

  async mostrarLoading(){
    (await this.loading).present();
  }

  async eliminarLoading(){
    (await this.loading).dismiss();
  }

  async getDatos(){
    this.irisService.getIrisC()
    .subscribe( resp => {
      // guardo los datos iris en el arreglo 
      this.iris.push( ...resp.iris );
    });
  
  }

  async getDatosEn(){
    this.irisService.getIris()
    .subscribe( resp => {
      // guardo los datos iris en el arreglo 
      this.irisE.push( ...resp.iris );
    });
  
  }

  //realizar calculos //
  getCalculos(){
    this.mostrarLoading();
    /*=========== CONTADORES DE SETOSA ============*/
    for(let j=0; j<this.iris.length; j++){

    let conSLsetosa=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].sepal_length === this.iris[j].sepal_length && this.irisE[i].class === "Iris-setosa"){
            conSLsetosa = conSLsetosa + 1;
      }
    }

    let conSWsetosa=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].sepal_width === this.iris[j].sepal_width && this.irisE[i].class === "Iris-setosa"){
            conSWsetosa = conSWsetosa + 1;
      }
    }

    let conPLsetosa=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].petal_length === this.iris[j].petal_length && this.irisE[i].class === "Iris-setosa"){
            conPLsetosa = conPLsetosa + 1;
      }
    }

    let conPWsetosa=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].petal_width === this.iris[j].petal_width && this.irisE[i].class === "Iris-setosa"){
            conPWsetosa = conPWsetosa + 1;
      }
    }

    /*=========== CONTADORES DE VERSICOLOR ============*/
    let conSLversicolor=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].sepal_length === this.iris[j].sepal_length && this.irisE[i].class === "Iris-versicolor"){
            conSLversicolor = conSLversicolor + 1;
      }
    }

    let conSWversicolor=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].sepal_width === this.iris[j].sepal_width && this.irisE[i].class === "Iris-versicolor"){
            conSWversicolor = conSWversicolor + 1;
      }
    }

    let conPLversicolor=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].petal_length === this.iris[j].petal_length && this.irisE[i].class === "Iris-versicolor"){
            conPLversicolor = conPLversicolor + 1;
      }
    }

    let conPWversicolor=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].petal_width === this.iris[j].petal_width && this.irisE[i].class === "Iris-versicolor"){
            conPWversicolor = conPWversicolor + 1;
      }
    }


    /*=========== CONTADORES DE VIRGINICA ============*/
    let conSLvirginica=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].sepal_length === this.iris[j].sepal_length && this.irisE[i].class === "Iris-virginica"){
            conSLvirginica = conSLvirginica + 1;
      }
    }

    let conSWvirginica=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].sepal_width === this.iris[j].sepal_width && this.irisE[i].class === "Iris-virginica"){
            conSWvirginica = conSWvirginica + 1;
      }
    }

    let conPLvirginica=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].petal_length === this.iris[j].petal_length && this.irisE[i].class === "Iris-virginica"){
            conPLvirginica = conPLvirginica + 1;
      }
    }

    let conPWvirginica=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].petal_width === this.iris[j].petal_width && this.irisE[i].class === "Iris-virginica"){
            conPWvirginica = conPWvirginica + 1;
      }
    }



    /*=========== CONTADORES DE GENERAL ============*/
    let conSLgeneral=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].sepal_length === this.iris[j].sepal_length){
            conSLgeneral = conSLgeneral + 1;
      }
    }

    let conSWgeneral=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].sepal_width === this.iris[j].sepal_width){
            conSWgeneral = conSWgeneral + 1;
      }
    }

    let conPLgeneral=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].petal_length === this.iris[j].petal_length){
            conPLgeneral = conPLgeneral + 1;
      }
    }

    let conPWgeneral=0;
    for(let i=0; i<this.irisE.length; i++){
      if(this.irisE[i].petal_width === this.iris[j].petal_width){
            conPWgeneral = conPWgeneral + 1;
      }
    }

    // realizo los calculos //
    let probSetosa = (conSLsetosa/33) * (conSWsetosa/33) * (conPLsetosa/33) * (conPWsetosa/33) * (33/99);
    let probVersicolor = (conSLversicolor/33) * (conSWversicolor/33) * (conPLversicolor/33) * (conPWversicolor/33) * (33/99);
    let probVirginica = (conSLvirginica/33) * (conSWvirginica/33) * (conPLvirginica/33) * (conPWvirginica/33) * (33/99);
    let probGeneral = (conSLgeneral/99) * (conSWgeneral/99) * (conPLgeneral/99) * (conPWgeneral/99);
    
    // calculos para cuando los 3 sean ceros 
    let aciertosSetosa = conSLsetosa + conSWsetosa + conPLsetosa + conPWsetosa;
    let aciertosVersicolor = conSLversicolor + conSWversicolor + conPLversicolor + conPWversicolor;
    let aciertosVirginica = conSLvirginica + conSWvirginica + conPLvirginica + conPWvirginica;
    let finalSetosa = 0;
    if(probSetosa !== 0){
        finalSetosa = probSetosa / probGeneral;
    }else{
        finalSetosa = 0;
    }

    let finalVersicolor = 0;
    if(probVersicolor !== 0){
        finalVersicolor = probVersicolor / probGeneral;
    }else{
        finalVersicolor = 0;
    }

    let finalVirginica = 0;
    if(probVirginica !== 0){
        finalVirginica = probVirginica / probGeneral;
    }else{
        finalVirginica = 0;
    }

    if(finalSetosa > finalVersicolor && finalSetosa > finalVirginica){
      this.iris[j].class = "Iris-setosa";
    }else if(finalVersicolor > finalSetosa && finalVersicolor > finalVirginica){
      this.iris[j].class = "Iris-versicolor";
    }else if(finalVirginica > finalSetosa && finalVirginica > finalVersicolor){
      this.iris[j].class = "Iris-virginica";
    }else if(finalSetosa === finalVersicolor && finalSetosa === finalVirginica){
      if(aciertosSetosa > aciertosVersicolor && aciertosSetosa > aciertosVirginica){
        this.iris[j].class = "Iris-setosa";
      }else if(aciertosVersicolor > aciertosSetosa && aciertosVersicolor > aciertosVirginica){
        this.iris[j].class = "Iris-versicolor";
      }else if(aciertosVirginica > aciertosSetosa && aciertosVirginica > aciertosVersicolor){
        this.iris[j].class = "Iris-virginica";
      }else{
        this.iris[j].class = "Iris-setosa";
      }
    }
    this.eliminarLoading();
  }

  }


  


  

}
