import { Component, OnInit } from '@angular/core';
import { Iris } from '../interfaces/intefaces';
import { IrisService } from '../services/iris.service';
import { LoadingController } from '@ionic/angular'; 

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page implements OnInit {
  
  iris: Iris[] = [];
  loading = this.loadingCtrl.create({message: 'Espere...'});
  constructor(private irisService: IrisService, private loadingCtrl: LoadingController) {
    this.mostrarLoading();
  }

  ngOnInit(){
    this.getDatos();
  }

  async getDatos(){
    this.irisService.getIrisC()
    .subscribe( resp => {
      // guardo los datos iris en el arreglo 
      this.iris.push( ...resp.iris );
      this.eliminarLoading();
    });
  
  }

  async mostrarLoading(){
    (await this.loading).present();
  }

  async eliminarLoading(){
    (await this.loading).dismiss();
  }

}
