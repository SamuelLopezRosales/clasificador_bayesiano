import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { RespuestaIris } from '../interfaces/intefaces';

const URL = environment.url;
@Injectable({
  providedIn: 'root'
})
export class IrisService {

  constructor(private http: HttpClient ) { }

  getIris(){
    return this.http.get<RespuestaIris>(`${ URL }/iris`);
  }

  getIrisC(){
    return this.http.get<RespuestaIris>(`${ URL }/iris2`);
  }
}
