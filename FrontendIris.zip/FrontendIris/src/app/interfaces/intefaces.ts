export interface Iris {
    id?: number;
    sepal_length?: number;
    sepal_width?: number;
    petal_length?: number;
    petal_width?: number;
    class?: string;
}

export interface RespuestaIris {
    ok?: boolean;
    iris?: Iris[];
}



